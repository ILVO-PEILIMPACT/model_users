#' Get GHG and GLG from sql-database
#'
#' @param file_sql character string, name of sql-file.
#' @param run_id vector, run id.
#' @importFrom stringr str_c
#' @importFrom fs path_file file_exists
#' @importFrom tibble as_tibble
#' @importFrom RSQLite dbConnect dbGetQuery dbDisconnect
#' @keywords internal
get_ghgglg_run_id <- function(file_sql, run_id) {

  # ---- initial part of procedure ----

  if (!file_exists(path = file_sql)) stop(str_c("sql-file '", file_sql,"' does not exists"))

  # ---- main part of procedure ----

  # extract GHG and GLG
  conn <- dbConnect(RSQLite::SQLite(), dbname = file_sql)
  statement <- str_c("SELECT run_id,ghg,glg FROM ghgglg WHERE run_id in ('", str_c(run_id, collapse = "','"), "')")
  db <- as_tibble(dbGetQuery(conn = conn, statement = statement))
  dbDisconnect(conn = conn)

  # check extraction
  if (nrow(db) == 0) stop(str_c("no records found in '", path_file(file_sql), "'"))

  # ---- return of procedure ----

  return(db)
}

#' Select run_id (based on GHG and GLG)
#'
#' @param database character string, version of WWL-database.
#' @param climate_id character string, id of climate period.
#' @param meteo_id numeric, id of meteo station.
#' @param soil_id numeric, id of soil.
#' @param crop_id numeric, id of crop.
#' @param irrigation_id numeric, id of irrigation.
#' @param solute_id numeric, id of solute.
#' @param ghg numeric, average highest groundwater level.
#' @param glg numeric, average lowest groundwater level.
#' @param ... further arguments passed to or from other methods
#' @return numeric, run_id (best option based on GHG and GLG).
#' @importFrom stringr str_c
#' @importFrom fs path_package dir_create
#' @importFrom tibble tibble add_row deframe
#' @importFrom dplyr %>% rename mutate select slice arrange if_else all_of
#' @importFrom controlR get_dir get_record create_label get_my_theme
#' @importFrom SWAPtools filter_run_id_SQL
#' @importFrom grDevices png dev.off
#' @importFrom ggplot2 ggplot geom_abline geom_point aes_string labs coord_fixed scale_colour_manual scale_x_continuous scale_y_continuous
#' @keywords internal
select_run_id <- function(database, climate_id, meteo_id, soil_id, crop_id, irrigation_id, solute_id, ghg, glg, ...) {

  # ---- initial part of procedure ----

  ghg_out <- glg_out <- ghgdiff <- glgdiff <- gxgdiff <- NULL

  # set optional arguments
  opt_param <- c("f_ghg", "f_glg", "create", "dir_out", "width", "height", "ghglim", "glglim", "breaks", "minorbreaks")
  f_ghg <- f_glg <- create <- dir_out <- width <- height <- ghglim <- glglim <- breaks <- minorbreaks <- NULL

  # load additional arguments
  param <- list(...)
  for (name in names(param) ) assign(name, param[[name]])

  # check unused arguments
  unused_param <- setdiff(names(param), opt_param)
  if (length(unused_param)) stop("unused parameter: ", str_c(unused_param, collapse = ', '))

  # check used arguments
  if (is.null(f_ghg)) f_ghg <- 1.0
  if (is.null(f_glg)) f_glg <- 1.0
  if (is.null(create)) create <- TRUE
  if (is.null(width)) width <- 6
  if (is.null(height)) height <- 6
  if (is.null(ghglim)) ghglim <- c(0.00, 2.50)
  if (is.null(glglim)) glglim <- c(0.00, 3.00)
  if (is.null(breaks)) breaks <- seq(0, 3, 1.0)
  if (is.null(minorbreaks)) minorbreaks <- seq(0, 3, 0.5)

  # ---- initial part of procedure ----

  # check if dir_out is specified (in case of create)
  if (create & is.null(dir_out)) stop("'dir_out' should be specified")

  # ---- main part of procedure ----

  # get run_id of selected plot
  file_sql <- str_c(path_package(package = "WWLmaatwerk"), "/db/WWL_metarelaties-__-", database, ".sqlite")
  run_id <- filter_run_id_SQL(
    file_sql = file_sql,
    climate_id = climate_id,
    meteo_id = meteo_id,
    soil_id = soil_id,
    crop_id = crop_id,
    irrigation_id = irrigation_id,
    solute_id = solute_id,
    scenario_id = "direct")

  # get simulated ghg and glg of selected plot
  file_sql <- str_c(path_package(package = "WWLmaatwerk"), "/db/WWL_GHGGLG-__-", database, ".sqlite")
  db <- get_ghgglg_run_id(
    file_sql = file_sql,
    run_id = run_id) %>%
    rename(ghg_out = ghg, glg_out = glg) %>%
    mutate(
      ghg_out = -0.01 * ghg_out,
      glg_out = -0.01 * glg_out,
      ghgdiff = abs(ghg_out - all_of(ghg) / 100),
      glgdiff = abs(glg_out - all_of(glg) / 100),
      gxgdiff = ghgdiff * all_of(f_ghg) + glgdiff * all_of(f_glg)
    ) %>%
    arrange(gxgdiff) %>%
    select(run_id, ghg_out, glg_out)

  s_run_id <- db %>%
    slice(1) %>%
    select(run_id) %>%
    deframe()

  # create figure
  if (create) {

    # create directory
    dir_create(path = dir_out)

    # prepare figure
    db <- db %>%
      mutate(cat = if_else(run_id == all_of(s_run_id), "beste optie", "overige opties")) %>%
      add_row(run_id = as.character(0), ghg_out = all_of(ghg) / 100, glg_out = all_of(glg) / 100, cat = "invoer")

    # create factor
    db$cat <- factor(x = db$cat, levels = c("invoer", "beste optie", "overige opties"), ordered = TRUE)

    # open device
    namfig <- str_c(dir_out, "/", s_run_id, ".png")
    png(filename = namfig, width = width * 150, height = height * 150, res = 144)

    G = ggplot(data = db)
    G = G + geom_abline(intercept = 0, slope = 1, colour = "grey", linetype = 2)
    G = G + geom_point(aes_string(x = "ghg_out", y = "glg_out", colour = "cat"), shape = 19, alpha = 0.6, na.rm = TRUE)
    G = G + scale_colour_manual(name = create_label(label = "Selectie"), values = c("red", "blue", "grey80"))
    G = G + labs(x = create_label(label = "Gemiddeld Hoogste Grondwaterstand", unit = "m-mv"), y = create_label(label = "Gemiddeld Laagste Grondwaterstand", unit = "m-mv"))
    G = G + coord_fixed(ratio = 1)
    G = G + scale_x_continuous(limits = ghglim, breaks = breaks, minor_breaks = minorbreaks)
    G = G + scale_y_continuous(limits = glglim, breaks = breaks, minor_breaks = minorbreaks)
    G = G + get_my_theme("figure")
    print(G)

    # close device
    suppressMessages(dev.off())
  }

  # ---- return of procedure ----

  return(s_run_id)
}

#' Create SWAP input based on run_id
#'
#' @param database character string, version of WWL-database.
#' @param run_id numeric, run_id.
#' @param dir_out character, output directory.
#' @importFrom utils unzip
#' @importFrom stringr str_c
#' @importFrom fs path_package
#' @importFrom readr read_rds
#' @importFrom SWAPtools get_run_info_SQL create_SWAP
#' @keywords internal
create_run_id <- function(database, run_id, dir_out) {

  # ---- initial part of procedure ----

  # load settings watervision agriculture
  settings_wwl <- read_rds(file = str_c(path_package(package = "WWLanalyse"), "/rds/wwl_settings.rds"))

  # set file_sql
  file_sql <- str_c(path_package(package = "WWLmaatwerk"), "/db/WWL_metarelaties-__-", database, ".sqlite")

  tmplt_swp <- str_c(path_package(package = "WWLmaatwerk"), "/template/swap.template")
  tmplt_dra <- str_c(path_package(package = "WWLmaatwerk"), "/template/drainage.template")

  dir_crp <- str_c(path_package(package = "WWLmaatwerk"), "/template/Gewas")
  dir_met <- str_c(path_package(package = "WWLmaatwerk"), "/template/Meteo")
  dir_ini <- str_c(path_package(package = "WWLmaatwerk"), "/template/Ini")

  # ---- main part of procedure ----

  # set ouput
  dir_run <- str_c(dir_out, "/run_", formatC(x = as.numeric(run_id), format = "d", width = 9, flag = "0"))

  # get run info
  run_info <- get_run_info_SQL(file_sql = file_sql, run_id = run_id)

  # extract file_ini
  file_ini <- tolower(str_c("swap-", run_info$soil_id, run_info$prof_id, "-", run_info$solute_id, "-", run_info$dr_id, ".ini"))
  file_zip <- str_c(dir_ini, "/inifiles_", database, ".zip")
  unzip(zipfile = file_zip, files = file_ini, overwrite = TRUE, exdir = dir_run)

  # extract file_crp
  cropinfo <- settings_wwl$cropinfo
  file_crp <- str_c(cropinfo$cropfile[match(x = run_info$crop_id, table = cropinfo$crop_id)], ".crp")
  if (run_info$crop_id %in% c(6:20)) file_crp <- c(file_crp, "vanggewas.crp")
  file_zip <- str_c(dir_crp, "/gewas_", database, ".zip")
  unzip(zipfile = file_zip, files = file_crp, overwrite = TRUE, exdir = dir_run)

  # create SWAP input
  file_swp <- str_c(dir_run, "/swap.swp")
  create_SWAP(file_swp = file_swp, file_sql = file_sql, run_id = run_id, tmplt_swp = tmplt_swp, dir_met = dir_met, dir_ini = dir_run, dir_crp = dir_run, tmplt_dra = tmplt_dra, quiet = TRUE)
}
