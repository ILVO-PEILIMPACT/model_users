#' Analyse SWAP run (based on Watervision Agriculture)
#'
#' @param file_swp character string, name of (SWAP)file (potential growing season)
#' @param type character string, id of soil physical unit ('BOFEK2012', 'BOFEK2020' or 'BODEM')
#' @param soil_id integer, id of soil physical unit
#' @param command character string, name of SWAP-program
#' @param dir_out character string, out-directory
#' @param ... further arguments passed to or from other methods
#' @importFrom stringr str_c
#' @importFrom fs path_file path_dir
#' @importFrom SWAPtools copy_SWAP run_SWAP
#' @importFrom WWLanalyse analyse_gwl analyse_harvest create_indirect create_harvestinfo
#' @keywords internal
analyse_swaprun <- function(file_swp, type, soil_id, command, dir_out, ...) {

  # ---- initial part of procedure ----

  # set optional arguments
  opt_param <- c("year_start", "year_end", "type", "width", "height", "settings_wwl", "variable_swap", "quiet")
  year_start <- year_end <- width <- height <- settings_wwl <- variable_swap <- quiet <- NULL

  # load additional arguments
  param <- list(...)
  for (name in names(param) ) assign(name, param[[name]])

  # check unused arguments
  unused_param <- setdiff(names(param), opt_param)
  if (length(unused_param)) stop("unused parameter: ", str_c(unused_param, collapse = ', '))

  # check used arguments
  if (is.null(width)) width <- 10
  if (is.null(height)) height <- 5
  if (is.null(settings_wwl)) settings_wwl <- read_rds(file = str_c(path_package(package = "WWLanalyse"), "/rds/wwl_settings.rds"))
  if (is.null(variable_swap)) variable_swap <- read_rds(file = str_c(path_package(package = "SWAPtools"), "/rds/swap_variables.rds"))
  if (is.null(quiet)) quiet <- TRUE

  # ---- main part of procedure ----

  # set names swp-files
  file_ind <- str_c(dir_out, "/Indirect/", path_file(file_swp))
  file_dir <- str_c(dir_out, "/Direct/", path_file(file_swp))

  # prepare swap runs
  copy_SWAP(file_swp = file_swp, dir_run = path_dir(file_dir), quiet = TRUE)
  copy_SWAP(file_swp = file_swp, dir_run = path_dir(file_ind), quiet = TRUE)
  create_indirect(file_swp = file_ind)

  # execute swap
  if (!quiet) message("\nrun SWAP direct...")
  run_SWAP(command = command, file_swp = file_dir, quiet = TRUE)
  if (!quiet) message("\nrun SWAP indirect...")
  run_SWAP(command = command, file_swp = file_ind, quiet = TRUE)

  # create harvest info
  create_harvestinfo(file_swp = file_dir, type = type, soil_id = soil_id, settings_wwl = settings_wwl, variable_swap = variable_swap, quiet = quiet)
  create_harvestinfo(file_swp = file_ind, type = type, soil_id = soil_id, settings_wwl = settings_wwl, variable_swap = variable_swap, quiet = quiet)

  # analyse groundwater level
  analyse_gwl(
    file_swp = file_dir, dir_out = dir_out,
    year_start = year_start, year_end = year_end,
    width = width, height = height,
    variable_swap = variable_swap, quiet= quiet)

  # analyse harvest
  analyse_harvest(
    file_ind = file_ind, file_dir = file_dir, dir_out = dir_out,
    year_start = year_start, year_end = year_end,
    width = width, height = height,
    settings_wwl = settings_wwl, variable_swap = variable_swap, quiet= quiet)
}
