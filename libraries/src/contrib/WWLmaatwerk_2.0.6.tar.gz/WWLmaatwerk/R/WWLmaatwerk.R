#' WWLmaatwerk
#'
#' De \href{https://waterwijzerlandbouw.wur.nl/index.html}{Waterwijzer Landbouw} (WWL) is een instrument voor het bepalen van het effect van veranderingen
#' in hydrologische condities op gewasopbrengsten. Deze veranderingen kunnen worden veroorzaakt door
#' waterbeheer, herinrichtingsprojecten, (drink)waterwinningen, maar ook door het klimaat.
#' Gewassen en de agrarische bedrijfsvoering stellen specifieke eisen aan de waterhuishouding.
#'
#' De WWL geeft een reproduceerbare inschatting van het effect, in termen van indirecte en directe
#' effecten waarbij de directe effecten verder zijn uitgesplist naar aandeel in droogte- zuurstof-
#' en/of zoutstress.
#'
#' De WWL bestaat uit verschillende methodieken, die verschillen in gemak om het toe te passen maar
#' natuurlijk ook in het detail en onderscheidings-vermogen van de resultaten.
#'
#' De metarelaties van WWL kunnen relatief eenvoudig worden benaderd met de WWL-tabel. Hiermee is
#' het mogelijk om relatief snel inzicht te krijgen hoe de opbrengstderving gedurende de
#' klimaatperioden 1981-2010 en 2036-2065 reageert voor een groot aantal gewassen onder
#' uiteenlopende bodemkundige, hydrologische en meteorologische condities. De hydrologische
#' condities worden gekarakteriseerd door de GHG en GLG.
#'
#' Om meer grip te krijgen op de modelresultaten is het mogelijk om over te gaan op een maatwerktoepassing
#' met WWL-maatwerk. Voor een specifieke situatie kan het modelinstrumentarium (SWAP-WOFOST) opnieuw
#' worden gedraaid. Door modelinstellingen aan te passen is het mogelijk om beter aan te sluiten op
#' de lokale omstandigheden. Zo kan er gebruik worden gemaakt van lokale meteogegevens, bodemfysica
#' en het grondwaterstandsverloop en kan het modelinstrumentarium worden gedraaid voor een
#' recentere periode.
#'
#' Maatwerk op het niveau van stroomgebieden is mogelijk met de WWL-regionaal toepassing. Hierbij
#' wordt informatie gebruikt over het landgebruik, bodemtype en een gedetailleerd
#' grondwaterstandsverloop en is het mogelijk om aan te sluiten op informatie afkomstig van
#' regionale hydrologische modelberekeningen (zoals bijvoorbeeld 14-daagse grondwaterstandsgegevens).
"_PACKAGE"
