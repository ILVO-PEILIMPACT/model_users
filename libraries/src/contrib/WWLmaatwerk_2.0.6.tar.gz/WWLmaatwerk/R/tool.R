#' Select SWAP run (based on Watervision Agriculture)
#'
#' @param file character string. Name of (control)file.
#' @return numeric, best variant of swaprunR.
#' @importFrom stringr str_c
#' @importFrom readr read_rds
#' @importFrom fs path_package
#' @importFrom controlR get_dir get_record
#' @importFrom apiwwl get_version
#' @export wwl_selectie
#' @examples
#' # specify controlfile
#' file <- system.file("extdata/control_selectie.inp", package = "WWLmaatwerk")
#'
#' # get specific run_id Watervision Agriculture
#' wwl_selectie(file = file)
wwl_selectie <- function(file) {

  # ---- initial part of procedure ----

  # load settings watervision agriculture
  wwl <- read_rds(file = str_c(path_package(package = "WWLanalyse"), "/rds/wwl_settings.rds"))

  # get version of WWL-database
  database <- get_record(file = file, item = "DATABASE", opt = get_version())

  # set selection plot
  climate_id <- get_record(file = file, item = "KLIMAAT",opt = "__")
  meteo_id <- get_record(file = file, item = "STATION",opt = wwl$STATION)
  soil_id <- get_record(file = file, item = "BODEM", opt = wwl$BODEM)
  gewas_id <- as.numeric(get_record(file = file, item ="GEWAS", opt = wwl[[str_c("GEWAS_", database)]]))
  irrigation_id <- get_record(file = file, item = "IRRIGATIE",opt = wwl$IRRIGATIE, item_exists = FALSE)
  if (is.null(irrigation_id)) irrigation_id <- 0
  solute_id <- get_record(file = file, item = "ZOUTCONC",opt = 0, item_exists = FALSE)
  if (is.null(solute_id)) solute_id <- 0

  # set groundwater characteristics
  ghg <- as.numeric(get_record(file = file, item = "GHG"))
  glg <- as.numeric(get_record(file = file, item = "GLG"))
  eenheid <- get_record(file = file, item = "EENHEID", opt = c("cm-mv", "cm+mv", "m-mv", "m+mv"))

  # set weight of groundwater characteristics
  f_ghg <- as.numeric(get_record(file = file, item = "fGHG"))
  f_glg <- as.numeric(get_record(file = file, item = "fGLG"))

  # set download
  download <- ifelse(get_record(file = file, item = "DOWNLOAD", opt = c("Yes", "No")) == "Yes", TRUE, FALSE)

  # set out-directory
  dir_out <- get_dir(file = file, item = "DIROUT", item_exists = download, create = FALSE)


  # ---- main part of procedure ----

  # check version of database
  if (database < "2.0.0") stop("WWL-maatwerk beschikbaar vanaf versie 2.0.0")
  if (max(get_version()) > database) message(str_c("WARNING update of WWL-database available: '", max(get_version(), "'")))

  # set crop
  crop_id <- wwl$cropinfo$crop_id[match(x = gewas_id, table = wwl$cropinfo$gewas_id)]

  # convert unit (cm-mv)
  if (eenheid != "cm-mv") {
    fact <- ifelse(eenheid == "m-mv", 100.0, ifelse(eenheid == "m+mv", -100.0, -1.0))
    ghg <- ghg * fact
    glg <- glg * fact
  }

  # get run_id
  run_id <- select_run_id(
    database = database,
    climate_id = climate_id,
    meteo_id = meteo_id,
    soil_id = soil_id,
    crop_id = crop_id,
    irrigation_id = irrigation_id,
    solute_id = solute_id,
    ghg = ghg,
    glg = glg,
    f_ghg = f_ghg,
    f_glg = f_glg,
    create = download,
    dir_out = dir_out)

  # download SWAP
  if (download) {
    create_run_id(database = database, run_id = run_id, dir_out = dir_out)
  }

  # ---- return of procedure ----

  return(run_id)

}

#' Analyse SWAP run (based on Watervision Agriculture)
#'
#' @param file character string. Name of (control)file.
#' @importFrom stringr str_c
#' @importFrom fs path_file
#' @importFrom controlR get_dir get_record
#' @export wwl_analyse
wwl_analyse <- function(file) {

  # ---- initial part of procedure ----

  # set directories
  dir_out <- get_dir(file = file, item = "DIROUT")

  # set SWAP run
  command <- get_record(file = file, item = "PRGSWP")
  file_swp <- get_record(file = file, item = "FILSWP")

  # set soil physical unit
  type <- get_record(file = file, item = "TYPE", opt = c("BODEM", "BOFEK2012", "BOFEK2020"))
  soil_id <- get_record(file = file, item = "BODEM")

  # set period (optional)
  year_start <- get_record(file = file, item = "YEAR_START", item_exists = FALSE)
  year_end <- get_record(file = file, item = "YEAR_END", item_exists = FALSE)

  # set format figure
  width <- get_record(file = file, item = "WIDTH", item_exists = FALSE)
  height <- get_record(file = file, item = "HEIGHT", item_exists = FALSE)

  # ---- main part of procedure ----

  # analyse specific swap run
  analyse_swaprun(
    file_swp = file_swp, type = type, soil_id = soil_id, command = command, dir_out = dir_out,
    year_start = year_start, year_end = year_end, width = width, height = height)

}

