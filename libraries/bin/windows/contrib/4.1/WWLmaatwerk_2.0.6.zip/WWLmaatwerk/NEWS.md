# WWLmaatwerk 2.0.6 (2022-05-09)

* update R-paketten

# WWLmaatwerk 2.0.5 (2022-04-22)

* hide internal functions in Help Pages

# WWLmaatwerk 2.0.4 (2021-08-16)

* update naar WWL-aansturing 3.0.0
* update R-paketten

# WWLmaatwerk 2.0.3 (2021-03-24)

* update WWLanalyse

# WWLmaatwerk 2.0.2 (2020-10-22)

* update R-paketten

# WWLmaatwerk 2.0.1 (2020-07-03)

* verwijzing naar template-files aangepast

# WWLmaatwerk 2.0.0 (2020-06-12)

* aansluiting op WWL-metarelaties 2.0.0

# WWLmaatwerk 1.0.1 (2019-12-02)

* update van dependencies controlR en SWAPtools

# WWLmaatwerk 1.0.0 (2019-10-20)

* eerste versie van de WWLmaatwerk beschikbaar op https://waterwijzerlandbouw.wur.nl/index.html
